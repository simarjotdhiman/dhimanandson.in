DHIMAN AND SON — MODERN CLASSIC WEBSITE (LEAD-GENERATION UPDATE)

FILES
- index.html: website home page and interactive 3D furniture concept viewer.

BUSINESS DETAILS INCLUDED
- DHIMAN AND SON
- Phone/WhatsApp: +91 94178 91548 and +91 78144 90823
- Email: dhimanandson@gmail.com
- Base: Chandigarh, India

WHAT'S IMPROVED
- Modern-classic forest green, cream, wood and brass design.
- Interactive 3D furniture concept viewer (requires internet access and WebGL).
- Improved page title, description, social preview metadata and structured business data.
- Expanded services and a quick FAQ section.
- Floating WhatsApp enquiry shortcut.
- Enquiry form prepares a WhatsApp message with customer name, contact, service and project details.
- Email alternative remains available.
- Clear wording that all-India design enquiries are welcome, while on-site delivery/installation is confirmed by location.

TEST LOCALLY
1. Extract the ZIP.
2. Open index.html in Chrome or Edge.
3. Test all phone, WhatsApp and email links.
4. Fill the enquiry form and verify that WhatsApp opens with a pre-filled message. The customer still has to press Send.
5. Check on a mobile-sized browser window and on a real phone.
6. The 3D viewer uses Three.js from a CDN, so internet access is needed. If it does not load, test another modern browser with WebGL enabled.

PUBLISH FOR FREE (STATIC WEBSITE)
1. Create/sign in to a GitHub account.
2. Create a public repository, e.g. dhiman-and-son-website.
3. Upload index.html to the repository root.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch; choose main and /(root), then Save.
6. Wait for the GitHub Pages URL to appear and test it on phone and desktop.
7. Add a custom domain later if purchased; follow the hosting provider's DNS instructions.

BEFORE PROMOTION
- Replace concept/mockup images with real completed-project photos where available.
- Do not claim service locations, reviews, warranties, years of experience or certifications unless accurate.
- Confirm delivery, installation, shipping, returns and payment terms with every customer in writing.
- The enquiry form does not save leads to a database; submissions open WhatsApp for the visitor to send manually.
- This is a static website and does not include a backend, online checkout, booking system or customer database.
